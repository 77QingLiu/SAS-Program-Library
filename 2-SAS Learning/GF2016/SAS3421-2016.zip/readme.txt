These programs are companion files to the SAS Global Forum 2016 Presentation:
   The New SAS� Map Data Sets

http://support.sas.com/resources/papers/proceedings16

SAS Institute Inc

Note:  Read the comments in each program before running.  Some preparation 
and modification is required so that libname and filename statements point to your installed location.

Base SAS and SAS/GRAPH are required to run the programs.  


