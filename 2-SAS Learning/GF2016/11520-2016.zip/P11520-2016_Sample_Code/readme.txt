SAS Paper 11520-2016: Releasing the Power of SAS� into Microsoft SharePoint
Author: Xiaogang (Isaac) Tang, Wyndham Destination Network
Date: March 14, 2016

P11520_2016_Sample_Code_IsaacTang.sas
Sample SAS code for this paper.

cars.csv
Output from CODE EXAMPLE 1 � HOW TO SEND A SINGLE FILE TO SHAREPOINT

cars.csv
class.csv
Output from CODE EXAMPLE 2 � HOW TO SEND MULITPLE FILES TO SHAREPOINT

attrlookup_cars.zip
Output from CODE EXAMPLE 3 � HOW TO SEND A ZIPPED FILE TO SHAREPOINT

nydj.csv
Output from CODE EXAMPLE 4 � HOW TO CREATE A DATA VISUALIZATION ON SHAREPOINT

new-d3-calendar-demo-citiday.html
This is a sample web page to illustrate data visualization on SharePoint.
You may upload this page and nydj.csv to your SharePoint Library.

