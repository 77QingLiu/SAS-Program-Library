        --
        README for programs for SAS Global Forum 2016 paper SAS4341-2016
        --
Figure 1: scatter_sg.sas
Figure 2: heatmap_sg.sas
Figure 3: heatmap_num_sg.sas
Figure 4: heatboxseries_sg.sas
Figure 5: parallelAxis_sg.sas

* Data sets *
Unfortunately, due to the large size of the data set being used in this paper,
we cannot provide them here.

You should be able to construct the data sets from their original sources:

- air_ontime_2012_q1 (for figures 1 to 4)
    The Bureau of Transportation Statistics:
    http://www.transtats.bts.gov/OT_Delay/OT_DelayCause1.asp
    lets you select carriers, airports and a start and end period. Once you
    hit submit, you can download a CSV file for the selected data from the 
    'Download Raw Data' link.

- weather_aus (for figure 5)
    The Bureau of Meterology, Australia:
    http://www.bom.gov.au/climate/dwo/
    This provides monthly data by locations in each states. Once you drill
    down far enough, there is a for 'plain text version' that provides a CSV
    file. You will need to append multiple files to get many locations over
    many months.

Once you have the CSV file, you can import it into SAS.

        --
        End README
        --
