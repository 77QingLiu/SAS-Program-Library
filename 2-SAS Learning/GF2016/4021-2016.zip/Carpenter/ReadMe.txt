README.TXT

Hands-on-Workshop:
User Defined Formats
Art Carpenter
(907) 865-9167
art@caloxy.com

The assumed path is	c:\how\carpenter

Subfolders include:
	\data		contains one dataset and format catalogs (both created with SAS9.4 64 bit)
			the format catalogs are respecified during the execution of the HOW			
	\Exercises	Exercise programs - these will generally not execute successfully - the point of the HOW
	\Solutions	Solution programs - these will for the most part execute successfully

The root folder (\carpenter) contains
	README.TXT	this file
	autoexec.sas	creates the libref FMTCLASS
			Specifies the global macro variable &PATH which contains the assumed path
	makeclinics.sas Creates/recreates the class data set if it gets blitzed 
	HOW User Formats.lnk	
			shortcut for SAS.EXE. 
 
Initialization options include:
			-autoexec
			-sasinitialfolder
			-aswtitle
                        %startin%  which is set to the assumed path