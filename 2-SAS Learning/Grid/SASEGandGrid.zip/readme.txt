The contents of this zip file are to facilitate use of SAS Enterprise Guide 
with SAS Grid Manager.  This readme file documents the purpose of each file in 
this zip file as well as where the files should be placed in your SAS Grid 
environment.  You should also review the "SAS Grid Computing for 9.2" 
documentation, specifically the chapter "Using SAS Enterprise Guide with a SAS 
Grid".  

It is recommended that all of the following *local.sas and *remote.sas files 
be copied to a shared location that is accessible to all EG clients and all 
grid nodes.  

htmllocal.sas  - file to propogate any ODS HTML settings to the grid session 
htmlremote.sas - file to submit ODS statements to specify HTML settings 
pdflocal.sas   - file to propogate any ODS PDF settings to the grid session
pdfremote.sas  - file to submit ODS statements to specify PDF settings 
rtflocal.sas   - file to propogate any ODS RTF settings to the grid session
rtfremote.sas  - file to submit ODS statements to specify RTF settings 
srxlocal.sas   - file to propogate any ODS SRX settings to the grid session 
srxremote.sas  - file to submit ODS statements to specify SRX settings 

The statements contained in pre_wrapper.sas and post_wrapper.sas should be 
included in the EG client by completing the following steps: 
1. In SAS Enterprise Guide, select Tools->Options to open the Options window.  
2. In the Options window, select SAS Programs. To enable SAS Enterprise Guide 
   tasks to run on a SAS grid, select Tasks->Custom Code instead.  
3. Select Insert custom SAS code before submitted code and then click Edit.  
4. Insert the lines contained in pre_wrapper.sas into the edit window.  
5. In the Options window, select Insert custom SAS code after submitted code, 
   and then click Edit.
6. Insert the lines contained in post_wrapper.sas into the edit window. 
Another option would be to include the statements in each wrapper file into a 
SAS autocall macro and include the autocall macros into the edit windows.

You will need to remove the check beside the EG option "Link handcoded ODS results".
This option can be found at Tools->Options->Results General.

You will need to update the appserver_autoexec_usermods.sas used by the server 
context so it defines the EGTASK libref as well as the _eg_conditional_dropds macro.
A sample appserver_autoexec_usermods.sas has been included.

You will need to set the "OdsOptionsToMacro" & "SuppressODSStatements" 
options in the SAS\Enterprise Guide4\SEGuide.exe.config file for each SAS 
Enterprise Guide client. Sample configuration files for the appropriate
Version of Enterprise Guide have been included:

4.2\SEGuide.exe.config - SAS Enterprise Guide Version 4.22 
4.1\SEGuide.exe.config - SAS Enterprise Guide Version 4.1 with hotfix 11 
                         (41EG11)

