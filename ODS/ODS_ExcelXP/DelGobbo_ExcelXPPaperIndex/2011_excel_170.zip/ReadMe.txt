Contents:
========

This ZIP archive contains the following files:

Paper - 2011 Multisheet Excel.pdf - PDF version of the paper "Creating Stylish Multi-Sheet Microsoft Excel Workbooks the Easy Way with SAS".

2011 Handouts.pdf - PDF version of the handouts for the workshop "Creating Stylish Multi-Sheet Microsoft Excel Workbooks the Easy Way with SAS".

ProstateCancer.sas7bdat - sample SAS table containing clinical trial data.

ExcelXP.sas - recent version of the ExcelXP ODS tagset.

CompleteCode.sas - complete sample code used in the hands-on workshop "Creating Stylish Multi-Sheet Microsoft Excel Workbooks the Easy Way with SAS".

Setup.sas - sets up the SAS operating environment.

Exercise1.sas - first attempt at making an XML file for Excel.

Exercise2.sas - Change the background color of alternating rows.

Exercise3.sas - Add traffic lighting to PROC REPORT output.

Exercise4.sas - Use ODS style overrides to center text.

Exercise5.sas - Use formatted BY group values for the worksheet names.

Exercise6.sas - Suppress BY line text in the worksheet body and add AutoFilters.

Exercise7.sas - Explicitly control the column widths.

ReadMe.txt - this file.

Solution2.sas - Solution to Exercise 2.

Solution3.sas - Solution to Exercise 3.

Solution4.sas - Solution to Exercise 4.

Solution5.sas - Solution to Exercise 5.

Solution6.sas - Solution to Exercise 6.

Solution7.sas - Solution to Exercise 7.

Documentation - ExcelXP Tagset Help v1.116.pdf - ExcelXP tagset documentation.

Paper - 2006 Multisheet Excel.pdf - PDF version of the paper "Creating AND Importing Multi-Sheet Excel Workbooks the Easy Way with SAS".

Paper - 2007 Multisheet Excel.pdf - PDF version of the paper "Creating Multi-Sheet Excel Workbooks the Easy Way with SAS".

Paper - 2008 Multisheet Excel.pdf - PDF version of the paper "Tips and Tricks for Creating Multi-Sheet Excel Workbooks the Easy Way with SAS".

Paper - 2009 Multisheet Excel.pdf - PDF version of the paper "More Tips and Tricks for Creating Multi-Sheet Excel Workbooks the Easy Way with SAS".

Paper - 2010 Multisheet Excel.pdf - PDF version of the paper "Traffic Lighting Your Multi-Sheet Microsoft Excel Workbooks the Easy Way with SAS".

Paper - Beginners Office.pdf - PDF version of the paper "A Beginner's Guide to Incorporating SAS Output in Microsoft Office Applications".

Paper - Cross Platform Office.pdf - PDF version of the paper "Techniques for SAS Enabling Microsoft Office in a Cross-Platform Environment".

Paper - Excel XML.pdf - PDF version of the paper "From SAS to Excel via XML".

Paper - Moving Data.pdf - PDF version of the paper "Moving Data and Analytical Results between SAS and Microsoft Office".

Content.MSO.lnk - Microsoft Windows shortcut to the directory containing the Excel error log.

Installation:
============

The sample SAS code assumes that you have unpacked the archive into the directory "C:\HOW\DelGobbo\".  If you unpack this archive to a different directory, you will need to modify the value of the SAMPDIR macro variable in the files:

Setup.sas
CompleteCode.sas

Additionally, all SAS output will be written to this directory.


Usage:
=====

Start SAS and submit CompleteCode.sas to execute all the sample code.  Alternatively, you can submit Setup.sas, followed by the other files of interest.