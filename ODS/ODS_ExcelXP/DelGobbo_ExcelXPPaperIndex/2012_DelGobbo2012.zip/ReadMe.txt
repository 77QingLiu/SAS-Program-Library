Contents:
========

This ZIP archive contains the following files:

CompleteCode.sas - complete sample code used in the hands-on workshop "An Introduction to Creating Multi-Sheet Microsoft Excel Workbooks the Easy Way with SAS".

ExcelXP.sas - recent version of the ExcelXP ODS tagset.

Exercise1.sas - first attempt at making an XML file for Excel.

Exercise2.sas - Change the workshet names.

Exercise3.sas - Embed title & footnote text into worksheet body.

Exercise4.sas - Adding a print header, print footer, and AutoFilter.

Exercise5.sas - Style overrides - Part 1.

Exercise6.sas - Style overrides - Part 2.

Setup.sas - sets up the SAS operating environment.

Solution1.sas - Solution to Exercise 1.

Solution2.sas - Solution to Exercise 2.

Solution3.sas - Solution to Exercise 3.

Solution4.sas - Solution to Exercise 4.

Solution5.sas - Solution to Exercise 5.

Solution6.sas - Solution to Exercise 6.

ReadMe.txt - this file.

2012 Handouts.pdf - PDF version of the handouts for the workshop "An Introduction to Creating Multi-Sheet Microsoft Excel Workbooks the Easy Way with SAS".

Documentation - ExcelXP Tagset Help v1.116.pdf - ExcelXP tagset documentation.

Paper - 2006 Multisheet Excel.pdf - PDF version of the paper "Creating AND Importing Multi-Sheet Excel Workbooks the Easy Way with SAS".

Paper - 2007 Multisheet Excel.pdf - PDF version of the paper "Creating Multi-Sheet Excel Workbooks the Easy Way with SAS".

Paper - 2008 Multisheet Excel.pdf - PDF version of the paper "Tips and Tricks for Creating Multi-Sheet Excel Workbooks the Easy Way with SAS".

Paper - 2009 Multisheet Excel.pdf - PDF version of the paper "More Tips and Tricks for Creating Multi-Sheet Excel Workbooks the Easy Way with SAS".

Paper - 2010 Multisheet Excel.pdf - PDF version of the paper "Traffic Lighting Your Multi-Sheet Microsoft Excel Workbooks the Easy Way with SAS".

Paper - 2011 Multisheet Excel.pdf - PDF version of the paper "Creating Stylish Multi-Sheet Microsoft Excel Workbooks the Easy Way with SAS".

Paper - 2012 Multisheet Excel.pdf - PDF version of the paper "An Introduction to Creating Multi-Sheet Microsoft Excel Workbooks the Easy Way with SAS".

Paper - Beginners Office.pdf - PDF version of the paper "A Beginner's Guide to Incorporating SAS Output in Microsoft Office Applications".

Paper - Cross Platform Office.pdf - PDF version of the paper "Techniques for SAS Enabling Microsoft Office in a Cross-Platform Environment".

Paper - Excel XML.pdf - PDF version of the paper "From SAS to Excel via XML".

Paper - Moving Data.pdf - PDF version of the paper "Moving Data and Analytical Results between SAS and Microsoft Office".

Content.MSO.lnk - Microsoft Windows shortcut to the directory containing the Excel error log.

Installation:
============

The sample SAS code assumes that you have unpacked the archive into the directory "C:\HOW\DelGobbo\".  If you unpack this archive to a different directory, you will need to modify the value of the SAMPDIR macro variable in the files:

Setup.sas
CompleteCode.sas

Additionally, all SAS output will be written to this directory.


Usage:
=====

Start SAS and submit CompleteCode.sas to execute all the sample code.  Alternatively, you can submit Setup.sas, followed by the other files of interest.